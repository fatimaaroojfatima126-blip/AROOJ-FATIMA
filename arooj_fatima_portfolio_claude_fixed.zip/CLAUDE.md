# Claude Code Instructions — Arooj Fatima Portfolio

You are working on a personal portfolio website for **Arooj Fatima**, a WordPress Website Developer.

## Your task
Inspect the existing project first, then improve and finish the portfolio website. Do not blindly replace the project or remove existing sections. Run it locally and verify the result before summarizing your work.

## Brand and visual direction
- Premium, distinctive, modern portfolio — not a generic template.
- Motion-rich but elegant: smooth entrance transitions, scroll reveal, subtle floating elements, refined hover states, and tasteful transitions.
- Keep animations lightweight and respect `prefers-reduced-motion`.
- The hero section must feature the owner's niqab portrait on the **right side** on desktop, with her introduction on the left. On mobile, stack the text and portrait cleanly.
- Use these exact brand colors:
  - Clay / warm grey-orange: `#B18676`
  - Dark azure: `#154752`
  - Deep dark azure: `#192D35`
  - Dark blue: `#111923`
  - Near-black green: `#040B02`
- Maintain excellent contrast, generous spacing, rounded project cards, refined typography, and a cohesive visual system.
- Do not add invented client testimonials, fake metrics, unsupported claims, or made-up work history.

## Owner and content
- Name: Arooj Fatima
- Positioning: WordPress Website Developer
- Skills to feature: WordPress, WooCommerce/e-commerce, Shopify, responsive website design, Canva, and basic on-page SEO.
- Contact email: `fatimaaroojfaima126@gmail.com`
- Do not show a phone number.
- Contact CTA should open an email draft to the address above.
- Use clear, professional English copy.

## Projects to feature
Show these three real project links as portfolio cards with working external links:
1. Elorey — https://elorey.com
2. Redwood Trading — https://redwoodtrading.shop
3. MAH Contracting — https://mah-contarcting.com/

Use accurate, modest descriptions. Do not claim a platform or technical feature as fact unless it is evident from the project or supplied by the owner. If you cannot inspect a live website, retain the supplied URL and use a neutral description.

## Services and prices
Display the prices exactly as supplied:
- WordPress Shopping Website — $98
- Service Website — $180
- Shopify Website — $90

If needed, label prices as “starting price” and make clear that final scope can affect the quote.

## Required sections
- Navigation
- Hero with portrait and clear call to action
- About
- Skills
- Selected projects
- Services and prices
- Work process
- Contact CTA
- Footer

## Technical requirements
- Keep the website responsive on desktop, tablet, and mobile.
- Ensure mobile navigation works with keyboard and screen readers.
- Ensure all links have meaningful accessible names, external links use safe `rel` attributes, and images have useful alt text.
- Avoid broken links, console errors, layout overflow, and unnecessary dependencies.
- Optimize for quick loading and accessible motion.
- Preserve the local portrait asset at `assets/arooj-profile.jpeg`. Do not replace it with a random image.
- Current project is a static website. Keep it deployable to GitHub Pages or Vercel unless there is a strong reason to change architecture.
- Keep the project easy for a beginner to edit.
- If you change the project structure, update this file and `README.md`.

## Before finishing
1. Inspect all existing files.
2. Run the site using an available local preview/server.
3. Check the hero image, all three project cards, pricing, email CTA, mobile menu, and responsive layout.
4. Fix obvious issues.
5. Tell the owner exactly which files changed and how to preview and publish to GitHub Pages or Vercel.
6. Do not claim deployment has happened unless you actually deploy it with authorization and verify the live URL.
