@echo off
cd /d "%~dp0"
echo Starting Arooj Fatima portfolio website...
echo Keep this window open while viewing the website.
where py >nul 2>nul
if %errorlevel%==0 (
  start "" http://localhost:8000
  py -m http.server 8000
  goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
  start "" http://localhost:8000
  python -m http.server 8000
  goto :end
)
echo Python was not found on this computer.
echo Open index.html directly in your browser, or install Python and try again.
pause
:end
