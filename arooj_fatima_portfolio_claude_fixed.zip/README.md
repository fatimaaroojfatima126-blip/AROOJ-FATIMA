# Arooj Fatima Portfolio

A responsive, animated one-page portfolio built with HTML, CSS, and vanilla JavaScript.

## Preview locally
1. Extract this folder.
2. Open `index.html` in a browser. For the best local development experience, use Antigravity's preview/live server.

## Before publishing
- Replace `assets/arooj-profile.jpeg` if you want to use a different portrait.
- Confirm that the project descriptions accurately describe your role in each website.
- The contact email is set to `fatimaaroojfaima126@gmail.com`.
- Add your LinkedIn, WhatsApp, and other contact links when ready.
- Check project URLs and prices before publishing.

## Publish
Push the files to a GitHub repository. You can use GitHub Pages for a static site, or import the repository into Vercel. No build step is required.

## Notes
The animated background, scrolling ticker, reveal-on-scroll effects, responsive navigation, project cards, and service pricing are all included. The portrait image is stored locally in `assets/`.

## Use with Claude Code
Open this folder in Claude Code. It will read `CLAUDE.md` for the portfolio requirements. Ask Claude to inspect the existing code, run the site, and improve it while preserving the brand colors, portrait, projects, service prices, and contact email.


## Easy local preview on Windows
1. Extract the ZIP completely.
2. Open the extracted folder.
3. Double-click `run-local.bat`. A browser tab should open at `http://localhost:8000`.
4. Keep the black terminal window open while using the site. Close it to stop the local server.

If the browser says `ERR_CONNECTION_REFUSED`, the server is not running. Double-click `run-local.bat` again and read any error shown in the terminal. This static site does not require `npm run dev`. You can also double-click `index.html` to open it directly.
